// How to explain everything
/*
TOMP
  |
  |--Administration
       |
       |---SomeDoc.rtf
           |-------------------------------------------------------------------
           |
           |[PATH/NAME]
           |
           |  [Start Doc]
           |
           ...
           |
           |
           |
           |
           |  [End Doc]
           |-------------------------------------------------------------------


*/

tompReport.go
//EG MOM.go








