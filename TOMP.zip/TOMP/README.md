<<<<<<< HEAD
{\rtf1\ansi\ansicpg1252\cocoartf1187\cocoasubrtf390
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset0 LucidaGrande;}
{\colortbl;\red255\green255\blue255;\red217\green11\blue0;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid1\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}
{\list\listtemplateid2\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid101\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid2}
{\list\listtemplateid3\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid201\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid3}
{\list\listtemplateid4\listhybrid{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\}.)}{\leveltext\leveltemplateid301\'03\'00.);}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid302\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li1440\lin1440 }{\listname ;}\listid4}
{\list\listtemplateid5\listhybrid{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\}.)}{\leveltext\leveltemplateid401\'03\'00.);}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{hyphen\}}{\leveltext\leveltemplateid402\'01\uc0\u8259 ;}{\levelnumbers;}\fi-360\li1440\lin1440 }{\listname ;}\listid5}
{\list\listtemplateid6\listhybrid{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\})}{\leveltext\leveltemplateid501\'02\'00);}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listname ;}\listid6}
{\list\listtemplateid7\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{square\}}{\leveltext\leveltemplateid601\'01\uc0\u9642 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid7}
{\list\listtemplateid8\listhybrid{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\})}{\leveltext\leveltemplateid701\'02\'00);}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listname ;}\listid8}
{\list\listtemplateid9\listhybrid{\listlevel\levelnfc1\levelnfcn1\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{upper-roman\}.}{\leveltext\leveltemplateid801\'02\'00.;}{\levelnumbers\'01;}\fi-360\li720\lin720 }{\listlevel\levelnfc3\levelnfcn3\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{upper-alpha\}.}{\leveltext\leveltemplateid802\'02\'01.;}{\levelnumbers\'01;}\fi-360\li1440\lin1440 }{\listlevel\levelnfc0\levelnfcn0\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{decimal\}.}{\leveltext\leveltemplateid803\'02\'02.;}{\levelnumbers\'01;}\fi-360\li2160\lin2160 }{\listname ;}\listid9}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}{\listoverride\listid2\listoverridecount0\ls2}{\listoverride\listid3\listoverridecount0\ls3}{\listoverride\listid4\listoverridecount0\ls4}{\listoverride\listid5\listoverridecount0\ls5}{\listoverride\listid6\listoverridecount0\ls6}{\listoverride\listid7\listoverridecount0\ls7}{\listoverride\listid8\listoverridecount0\ls8}{\listoverride\listid9\listoverridecount0\ls9}}
\margl1440\margr1440\vieww14540\viewh12160\viewkind1
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\qc

\f0\b\fs72 \cf0 The \cf2 O\cf0 pen Mars Project\

\i\b0\fs24 \'93If the public raises the low-bar, everyone will go higher!\'94
\i0  \
							-
\b T\cf2 O\cf0 MP
\b0 , July 1, 2013\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 Mission Statement:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs24 \cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li725\fi2\pardirnatural\qj
\cf0 Create a platform for the future 
\b Visitation, Exploration, & Settlement (VES) of Mars
\b0  by Crowd-Sourcing a Stem-to-Stern Plan, leveraging public domain records , Open Source Technology, and the free-time of students, enthusiasts, academics, professionals, and retirees. We seek to establish and maintain a rising platform, upon which all can stand, so that 
\b no Mars Mission is less than successful
\b0  but also that so many more can 
\b exceed expectations
\b0 . If the public raises the low-bar everyone will go higher!\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 Our 21st Century Opportunity:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b\fs24 \cf0 \
Mars\'85
\b0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls1\ilvl0\cf0 {\listtext	\uc0\u8259 	}is the next destination for a field that yields incredible research dividends.\
{\listtext	\uc0\u8259 	}is our best chance to spread humanity in to space, for at least the next century.\
{\listtext	\uc0\u8259 	}is not the Moon, and will have strategic value for countries, multi-national corporations, and research institutions.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b \cf0 Mars-One\'85\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls2\ilvl0
\b0 \cf0 {\listtext	\uc0\u8259 	}is 
\b \ul bold
\b0 \ulnone  but What about Mars-Two? Mars-Three? Mars-Year2149?\
{\listtext	\uc0\u8259 	}may not be the best approach\'85 or even close. What would you improve?\
{\listtext	\uc0\u8259 	}will teach us lessons which should be learned ASAP, no matter what.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b \cf0 The Open Source Movement\'85
\b0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls3\ilvl0\cf0 {\listtext	\uc0\u8259 	}proves that spare time of 
\b brilliance
\b0  can be harnessed successfully. \
{\listtext	\uc0\u8259 	}shows that complexity is no enemy of world-wide collaboration.\
{\listtext	\uc0\u8259 	}demonstrates that public-private cooperation can be mutually-beneficial.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 Vision Of Success 
\i (
\i0 VOS 
\i v0.1 - Excerpt)
\i0 :\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs24 \cf0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls4\ilvl0\cf0 {\listtext	1.)	}The Product is a complete & copy-able plan, that demonstrate the best in:\
\pard\tx716\tx1079\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1078\fi-1079\pardirnatural
\ls4\ilvl1\cf0 {\listtext	\uc0\u8259 	}Materials, Design (CAD), Construction, Software\
{\listtext	\uc0\u8259 	}AeroSpace, Nuclear, & Agricultural Engineering, \
{\listtext	\uc0\u8259 	}AstroPhysics, Aeronautics, Chemistry, Geology\
{\listtext	\uc0\u8259 	}Logistics, Government, Community Planning, Social Activism\
{\listtext	\uc0\u8259 	}Marketing, A/V, Financing (crowd-funding)\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls4\ilvl0\cf0 {\listtext	2.)	}The First Product by July 1, 2015 (TOMP vXXXX.Q)\
{\listtext	3.)	}The Product is a versioned and quarterly-updated document, needing only .\
{\listtext	5.)	}A lowered Barrier of Entry for all space-related exploration.
\fs36 \
{\listtext	6.)	}Vision Of Success 
\i (
\i0 VOS 
\i v0.1 - Excerpt - cont.)
\i0 :\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs24 \cf0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls5\ilvl0\cf0 {\listtext	1.)	}A versioned, living-document that is a COMPLETE plan (Just Add Money!):\
\pard\tx716\tx1079\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1078\fi-1079\pardirnatural
\ls5\ilvl1\cf0 {\listtext	\uc0\u8259 	}Materials, Computer Aided Design (CAD), Construction, Software Engineering\
{\listtext	\uc0\u8259 	}Logistics, Nuclear, & Agricultural Engineering, \
{\listtext	\uc0\u8259 	}Nuclear Physics, Aeronautics, Astronomy, Geology\
{\listtext	\uc0\u8259 	}Government, Community Planning, Social Activism\
{\listtext	\uc0\u8259 	}Marketing, A/V, Financing (crowd-funding)\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls5\ilvl0\cf0 {\listtext	2.)	}The plan has complete, and \
{\listtext	3.)	}A lowered Barrier of Entry for all space-related exploration.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\i \cf0 Insanity? Revisable? 
\i0 \
   4.)	Sustainable Colonies by 2050. -TompCat   \

\i \
To be deleted soon enough!:
\i0 \
   5.)    The First Complete Plan by July 1, 2015 (TOMP vXXXX.Q)\
   6.)	Quarter-Annual Stable Updates, thereafter.\
\

\i To be deleted sooner!:
\i0 \
   7.)	Finish Drafting the TOMPL (see below) to ensure contribution equity.\
	\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 \page The Initial Sketch 
\i (v1.X)
\i0 :
\fs24 \
 - Includes this document (TOMP README v0.1) &\
	Vision of Success (TOMP VOS v0.1)\
 - has a vision, and will be archived as a zip for posterity\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \ul \ulc0 The Founding Principles:\ulnone \
\pard\tx716\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx220\tx720\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls6\ilvl0\cf0 {\listtext	1)	}
\b Licensing Is Important
\b0  (despite wanting to concentrate on the meat of the problem, this is potentially crippling, so): \
{\listtext	2)	}
\b Research Sourced from the Public Domain
\b0  (is a start, which birthed a)\
{\listtext	3)	}
\b Multi-Pronged Licensing-Compliance Approach
\b0  (meaning parallel approaches along a continuum from proverbial Off-The-Shelf Parts to Free-As-in-Beer components you build for the project, and points in between. Thus...).\
{\listtext	4)	}
\b All Open-Source Tools, Formats, & Platforms
\b0  (so anyone can \ul try\ulnone  to contribute, because) \
{\listtext	5)	}
\b Every Part of the Project is Important
\b0  (no matter how un-technical or trivial it seems, because)\
{\listtext	6)	}
\b Failure is In the Details
\b0  (in that no-one wants to travel 55 million kilometers and figure out the botanists forgot what\'92s edible or there isn\'92t enough money to send the other modules, because of some other unforeseen error, so)\
{\listtext	7)	}
\b Hard Work Saves Lives
\b0  (because it may be your children on a mission some day, where they use derivative technology). \
{\listtext	8)	}
\b Modularity in All Things:
\b0  from TOMP Organization to The Product (but\'85)\
{\listtext	9)	}
\b When in Doubt, Just Add Money
\b0 \'85 (meaning: always use Off-The-Shelf Parts to complete the design as opposed to not completing the design. For instance: NASA has will continue to use the RS-25 Engine so we assume that we will use it as well, as it will be a long time before an alternative can be built from scratch)\
{\listtext	10)	}
\b Use Forward- Thinking Technology
\b0 : Today\'92s Emerging Technology is the next decade\'92s solid foundation, crumbling infrastructure, or vaporware. (with that said:)\
{\listtext	11)	}
\b C89 Can Run on Anything; We need shielded microprocessors; Let\'92s not get ahead of ourselves.
\b0 \
\pard\tx720\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \ul \ulc0 \page \pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 Participation (V0.1 - excerpt):
\fs24 \ulnone \
Participation Levels, Voting Rights\
\
\
Observer - The Public At Large 				(No vote)\
\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b \cf0 \ul Participant Class:
\i\b0 \ulnone  registered user
\i0 \
Participant 1 - Registered User (Question-Asker)	(1 vote)\
Participant 2 - Recently-Active Registered User		(1 vote + Vote Weight)\
Participant 3 - Participant Eligible to Contribute		(Vote weight >= 2 votes)\
\

\b \ul Contributor Class:
\i\b0 \ulnone  P3 + successful committer, guaranteed credit
\i0 \
Contributor 1 - Participant Manager			(Vote Weight)\
Contributor 2 - Peer-Reviewed Contribution		(VW w/ VoteDown)\
Contributor 3 - Contribution Arbitration			(VW w/ VD& Arbitration Vote)\
\

\b \ul Guru Class:
\i\b0 \ulnone  C3 + Strategy, Tactics, & Ultimate Deliverable Responsibility
\i0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 Guru 1 - Arbitrator of Arbitrators				(C3 + )\
Guru 2 - Another Level that is important			(G1 +)\
Guru 3 - Manage Sub-Divisions				(G2 )\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b \cf0 \ul \ulc0 Division Heads:
\i\b0 \ulnone  G3 + Fiat, Inter-departmental Requests
\i0 \
Division Operations Chief					G3 + (\'bc) Division \
Vice President of Division					G3 + (\'bc) Division \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 President of Division					G3 + (\'bd + 1) Division \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\
\

\b \ul Definition of Terms:
\b0 \ulnone \
Vote		- A vote, for or against\
Vote Weight	- Earned Vote Weight, calculated continuously\
Vote Down 	- A vote against the existence of a question or matter-at-hand\
Arb Vote	- A Vote to pick between two votes\
\

\fs36 \page The Initial Sketch (v1.X - cont.):
\fs24 \
 - Includes this document (TOMP README v0.1), \
	Vision of Success (TOMP VOS v0.1)\
 - has a vision, and will be archived as a zip for posterity\
\
\
\

\fs26 \
The initial approach to modularity
\fs36 \page Licensing 
\i (v0.1)
\i0 :
\fs24 \
\

\b The Open Mars Project License 
\b0 (
\b TOMPL
\b0 ) is a forward-thinking, Open-ish License that encourages \'93forking,\'94 asks for nothing up-front, and seeks to serve the best interests of the project. \
TOMP
\b  
\b0 \'93Attribution for Contributors\'94 (
\b TOMPAC
\b0 ) is a primary goal, with plans to properly honor (and memorialize) every Contributor. Also participation and contribution are strictly catalogued with the intent to eventually compensate contributors for any Intellectual Property Licensing (IPL), however incidental. \
At the very least, any & every mission in to space with derivative work will be required to publish such and take steps to have the specific contributors acknowledged, as well as TOMP as a whole.  \
TOMPAC, in the next decades will be managed by the organization in a fair and non-restrictive way, but the imagination wonders\'85 (A book with contributors name placed on Mars \'97> a Monument to the TOMP Participants \'97> Clone Me on Mars\'85 use your imagination).\
\

\b TOMP\'92s Intentions in drafting the future TOMPL:
\b0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls7\ilvl0\cf0 {\listtext	
\f1 \uc0\u9642 
\f0 	}To use open source technology as much as possible while delineating the licensing & purchasing requirements of any proprietary technology. Including open-source projects by reference, where necessary.\
{\listtext	
\f1 \uc0\u9642 
\f0 	}Our intent is that no individual or entity gain undue compensation or advantage as a result of the contribution of others. \
{\listtext	
\f1 \uc0\u9642 
\f0 	}Our intent is not to furnish any named member with anything other than due-compensation, upon review of the Board of Governance, the Contributors, and the participants at large, should a 4/5ths vote be called.\
{\listtext	
\f1 \uc0\u9642 
\f0 	}This is all very boring but will be settled soon.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\

\fs36 \page Governance 
\i (v0.1 - proposed)
\i0 :
\fs24 \
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b\fs28 \cf0 \ul Chief Officers: 
\fs24 \ulnone \

\i\b0 (elected bi-annually)
\i0 \
\
CEO:	Chief Evangelical Officer	(The Face)\
CTO: 	Chief Technology Officer 	(Tech Guy)\
CFO: 	Chief Financial Officer 	(Cost-Cutter)\
COO: 	Chief Licensing Officer	(The Whip)\
\
These individuals are charged with the foundation and continued development of the project, to serve its Mission Statement in the interest of the current Vision of Success.\
\

\b\fs28 \ul Executive Board:
\b0  
\fs24 \ulnone \

\i (elected annually - July 1st)\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\i0 \cf0 \
Consists of nine (9) individuals. \
\
Three (3) individuals in the fields:\

\b Science, Engineering, 
\b0 or
\b  Stage Expertise
\b0  \
\
for each the 3 stages: \

\b Visitation, Exploration, & Settlement
\b0 \
\
In this way, the Executive Board is comprised of 6 orthogonal sub-committees of three people , stage-wise and type-wise:\
\
			Visitation		Exploration		Settlement\
Science		\
\
Engineering\
\
Stage Expertise\
\ul \
Definition of Scope:\
\ulnone \

\b Visitation
\b0  - The mission to visit Mars, orbit, and return\'85 from scratch.\

\b Exploration
\b0  - Once orbiting, how to land, explore, & return materials from surface.\

\b Settlement
\b0  -	Once landed, the temporary-to-longterm settlement of Mars.\
\

\b Science
\b0  - The theoretical (AstroPhysics, Geology, Biology, etc.)\

\b Engineering
\b0  - The practical (Aerospace, Robotics, Agricultural, etc)\

\b Stage Expertise
\b0  - The experience (Astronauts, Archeologists, Survivalists, etc.)\
\
Each intersection of these intersections is an 
\b Executive Board Member
\b0 .\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b\fs28 \cf0 \ul Chairman & Vice-Chairman:
\b0  \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs24 \cf0 \ulnone Those, the 4 Officers, plus the EB9, Comprise a 13 Member Board who elect a Vice-Chairman and then Chairman. The Chairman has the powers vested in the Chief Executive Officer of the Organization. The serves as Chief-of-Staff & Interim.\
\
[For the purpose of any forked project, the Chairman & Vice-Chairman section can serve as entry points for control: the head of your project & his deputy; the powers therein can be changed here.]\
\
All named members comprise the 15-Vote, Some-Number Member Board of Governance.\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\b\fs28 \cf0 \ul Departments:
\b0  
\fs24 \ulnone \
One under each Officer (functionally supportive of the...)\
\

\b\fs28 \ul Divisions:
\b0  
\fs24 \ulnone \
One for each Stage (which produces The Product, in aggregate).\
\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 Process (suffrage):\

\fs24 \
\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls8\ilvl0\cf0 1)	Strategy: The Overall Approach\
{\listtext	2)	}Modularity in All Things (MAT): from TOMP Organization to the Product\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural
\cf0 \
\

\fs36 \page Action Plan 
\i (v0.1)
\i0 \

\fs24 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls9\ilvl0\cf0 {\listtext	I.	}Research Phase:\
\pard\tx940\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1440\fi-1440\pardirnatural
\ls9\ilvl1\cf0 {\listtext	A.	}Document Dump\
\pard\tx1660\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li2160\fi-2160\pardirnatural
\ls9\ilvl2\cf0 {\listtext	1.	}Soviet Space Program (and successors)\
{\listtext	2.	}US NASA\
{\listtext	3.	}European Space Agency ESA\
{\listtext	4.	}Italian Space Agency (ASI)\
{\listtext	5.	}Japan Aerospace Exploration Agency (JAXA)\
{\listtext	6.	}Chinese National Space Administration (CNSA)\
{\listtext	7.	}Indian Space Research Organisation (ISRO)\
{\listtext	8.	}Israel Space Agency (ISA)\
{\listtext	9.	}Iranian Space Agency (ISA)\
{\listtext	10.	}\
\pard\tx940\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1440\fi-1440\pardirnatural
\ls9\ilvl1\cf0 {\listtext	B.	}Document Licensing Consideration\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls9\ilvl0\cf0 {\listtext	II.	}Recruitment\
\pard\tx940\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1440\fi-1440\pardirnatural
\ls9\ilvl1\cf0 {\listtext	A.	}Materials - The How\
\pard\tx1660\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li2160\fi-2160\pardirnatural
\ls9\ilvl2\cf0 {\listtext	1.	}Social Media\
{\listtext	2.	}Invitations\
{\listtext	3.	}Miscellaneous\
\pard\tx940\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li1440\fi-1440\pardirnatural
\ls9\ilvl1\cf0 {\listtext	B.	}Participants\
{\listtext	A.	}Contributors\
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\pardirnatural
\ls9\ilvl0\cf0 {\listtext	IV.	}TOMPL Completion\
{\listtext	V.	}Governance Review Planning\
{\listtext	VI.	}Elections\
{\listtext	VII.	} The First Complete Plan by July 1, 2015 (TOMP vXXXX.Q)\
{\listtext	VIII.	}Quarter-Annual Stable Updates, thereafter.\
{\listtext	IX.	}\
}
=======
TOMP

==================

The Open Mars Project

“If the public raises the low-bar, everyone will go higher!” 
							-TOMP, July 1, 2013


Mission Statement:

Create a platform for the future Visitation, Exploration, & Settlement (VES) of Mars by Crowd-Sourcing a Stem-to-Stern Plan, leveraging public domain records , Open Source Technology, and the free-time of students, enthusiasts, academics, professionals, and retirees. We seek to establish and maintain a rising platform, upon which all can stand, so that no Mars Mission is less than successful but also that so many more can exceed expectations. If the public raises the low-bar everyone will go higher!

Our 21st Century Opportunity:

Mars…
	⁃	is the next destination for a field that yields incredible research dividends.
	⁃	is our best chance to spread humanity in to space, for at least the next century.
	⁃	is not the Moon, and will have strategic value for countries, multi-national corporations, and research institutions.

Mars-One…
	⁃	is bold but What about Mars-Two? Mars-Three? Mars-Year2149?
	⁃	may not be the best approach… or even close. What would you improve?
	⁃	will teach us lessons which should be learned ASAP, no matter what.

The Open Source Movement…
	⁃	proves that spare time of brilliance can be harnessed successfully. 
	⁃	shows that complexity is no enemy of world-wide collaboration.
	⁃	demonstrates that public-private cooperation can be mutually-beneficial.


==========

Vision Of Success (VOS v0.1 - Excerpt):

	1.)	The Product is a complete & copy-able plan, that demonstrate the best in:
	  ⁃	Materials, Design (CAD), Construction, Software
	  ⁃	AeroSpace, Nuclear, & Agricultural Engineering, 
	  ⁃	AstroPhysics, Aeronautics, Chemistry, Geology
	  ⁃	Logistics, Government, Community Planning, Social Activism
	  ⁃	Marketing, A/V, Financing (crowd-funding)
	2.)	The First Product by July 1, 2015 (TOMP vXXXX.Q)
	3.)	The Product is a versioned and quarterly-updated document, needing only .
	5.)	A lowered Barrier of Entry for all space-related exploration.
	6.)	Vision Of Success (VOS v0.1 - Excerpt - cont.):

	1.)	A versioned, living-document that is a COMPLETE plan (Just Add Money!):
	  ⁃	Materials, Computer Aided Design (CAD), Construction, Software Engineering
	  ⁃	Logistics, Nuclear, & Agricultural Engineering, 
	  ⁃	Nuclear Physics, Aeronautics, Astronomy, Geology
	  ⁃	Government, Community Planning, Social Activism
	  ⁃	Marketing, A/V, Financing (crowd-funding)
	2.)	The plan has complete, and 
	3.)	A lowered Barrier of Entry for all space-related exploration.

Insanity? Revisable? 
   4.)	Sustainable Colonies by 2050. -TompCat   

To be deleted soon enough!:
   5.)  The First Complete Plan by July 1, 2015?? (TOMP vXXXX.Q)
   6.)	Quarter-Annual Stable Updates, thereafter.

To be deleted sooner!:
   7.)	Finish Drafting the TOMPL (see below) to ensure contribution equity.

	
==========

The Founding Principles:

	1)	Licensing Is Important (despite wanting to concentrate on the meat of the problem, this is potentially crippling, so): 
	2)	Research Sourced from the Public Domain (is a start, which birthed a)
	3)	Multi-Pronged Licensing-Compliance Approach (meaning parallel approaches along a continuum from proverbial Off-The-Shelf Parts to Free-As-in-Beer components you build for the project, and points in between. Thus...).
	4)	All Open-Source Tools, Formats, & Platforms (so anyone can try to contribute, because) 
	5)	Every Part of the Project is Important (no matter how un-technical or trivial it seems, because)
	6)	Failure is In the Details (in that no-one wants to travel 55 million kilometers and figure out the botanists forgot what’s edible or there isn’t enough money to send the other modules, because of some other unforeseen error, so)
	7)	Hard Work Saves Lives (because it may be your children on a mission some day, where they use derivative technology). 
	8)	Modularity in All Things: from TOMP Organization to The Product (but…)
	9)	When in Doubt, Just Add Money… (meaning: always use Off-The-Shelf Parts to complete the design as opposed to not completing the design. For instance: NASA has will continue to use the RS-25 Engine so we assume that we will use it as well, as it will be a long time before an alternative can be built from scratch)
	10)	Use Forward- Thinking Technology: Today’s Emerging Technology is the next decade’s solid foundation, crumbling infrastructure, or vaporware. (with that said:)
	11)	C89 Can Run on Anything; We need shielded microprocessors; Let’s not get ahead of ourselves.


==========

Participation (V0.1 - excerpt):
Participation Levels, Voting Rights


Observer - The Public At Large 				(No vote)

Participant Class: registered user
Participant 1 - Registered User (Question-Asker)	(1 vote)
Participant 2 - Recently-Active Registered User		(1 vote + Vote Weight)
Participant 3 - Participant Eligible to Contribute		(Vote weight >= 2 votes)

Contributor Class: P3 + successful committer, guaranteed credit
Contributor 1 - Participant Manager			(Vote Weight)
Contributor 2 - Peer-Reviewed Contribution		(VW w/ VoteDown)
Contributor 3 - Contribution Arbitration			(VW w/ VD& Arbitration Vote)

Guru Class: C3 + Strategy, Tactics, & Ultimate Deliverable Responsibility
Guru 1 - Arbitrator of Arbitrators				(C3 + )
Guru 2 - Another Level that is important			(G1 +)
Guru 3 - Manage Sub-Divisions				(G2 )

Division Heads: G3 + Fiat, Inter-departmental Requests
Division Operations Chief					G3 + (¼) Division 
Vice President of Division					G3 + (¼) Division 
President of Division					G3 + (½ + 1) Division 



Definition of Terms:
Vote		- A vote, for or against
Vote Weight	- Earned Vote Weight, calculated continuously
Vote Down 	- A vote against the existence of a question or matter-at-hand
Arb Vote	- A Vote to pick between two votes

The Initial Sketch (v1.X - cont.):
 - Includes this document (TOMP README v0.1), 
	Vision of Success (TOMP VOS v0.1)
 - has a vision, and will be archived as a zip for posterity


==========

The initial approach to modularity:Licensing (v0.1):

The Open Mars Project License (TOMPL) is a forward-thinking, Open-ish License that encourages “forking,” asks for nothing up-front, and seeks to serve the best interests of the project. 
TOMP “Attribution for Contributors” (TOMPAC) is a primary goal, with plans to properly honor (and memorialize) every Contributor. Also participation and contribution are strictly catalogued with the intent to eventually compensate contributors for any Intellectual Property Licensing (IPL), however incidental. 
At the very least, any & every mission in to space with derivative work will be required to publish such and take steps to have the specific contributors acknowledged, as well as TOMP as a whole.  
TOMPAC, in the next decades will be managed by the organization in a fair and non-restrictive way, but the imagination wonders… (A book with contributors name placed on Mars —> a Monument to the TOMP Participants —> Clone Me on Mars… use your imagination).

TOMP’s Intentions in drafting the future TOMPL:
	▪	To use open source technology as much as possible while delineating the licensing & purchasing requirements of any proprietary technology. Including open-source projects by reference, where necessary.
	▪	Our intent is that no individual or entity gain undue compensation or advantage as a result of the contribution of others. 
	▪	Our intent is not to furnish any named member with anything other than due-compensation, upon review of the Board of Governance, the Contributors, and the participants at large, should a 4/5ths vote be called.
	▪	This is all very boring but will be settled soon.


==========

Governance (v0.1 - proposed):

Chief Officers: 
(elected bi-annually)

CEO:	Chief Evangelical Officer	(The Face)
CTO: 	Chief Technology Officer 	(Tech Guy)
CFO: 	Chief Financial Officer 	(Cost-Cutter)
COO: 	Chief Licensing Officer	(The Whip)

These individuals are charged with the foundation and continued development of the project, to serve its Mission Statement in the interest of the current Vision of Success.

Executive Board: 
(elected annually - July 1st)

Consists of nine (9) individuals. 

Three (3) individuals in the fields:
Science, Engineering, or Stage Expertise 

for each the 3 stages: 
Visitation, Exploration, & Settlement

In this way, the Executive Board is comprised of 6 orthogonal sub-committees of three people , stage-wise and type-wise:

			Visitation	Exploration	Settlement
Science
Engineering
Stage Expertise	

Definition of Scope:

Visitation - The mission to visit Mars, orbit, and return… from scratch.
Exploration - Once orbiting, how to land, explore, & return materials from surface.
Settlement -	Once landed, the temporary-to-longterm settlement of Mars.

Science - The theoretical (AstroPhysics, Geology, Biology, etc.)
Engineering - The practical (Aerospace, Robotics, Agricultural, etc)
Stage Expertise - The experience (Astronauts, Archeologists, Survivalists, etc.)

Each intersection of these intersections is an Executive Board Member.
Chairman & Vice-Chairman: 
Those, the 4 Officers, plus the EB9, Comprise a 13 Member Board who elect a Vice-Chairman and then Chairman. The Chairman has the powers vested in the Chief Executive Officer of the Organization. The serves as Chief-of-Staff & Interim.

[For the purpose of any forked project, the Chairman & Vice-Chairman section can serve as entry points for control: the head of your project & his deputy; the powers therein can be changed here.]

All named members comprise the 15-Vote, Some-Number Member Board of Governance.

Departments: 
One under each Officer (functionally supportive of the...)

Divisions: 
One for each Stage (which produces The Product, in aggregate).


==========

Process (suffrage):

1)	Strategy: The Overall Approach
2)	Modularity in All Things (MAT): from TOMP Organization to the Product
(to be continued...)


==========

Action Plan (v0.1)

	I.	Research Phase:
	  A.	Document Dump
	    1.	Soviet Space Program (and successors)
	    2.	US NASA
    	3.	European Space Agency ESA
	    4.	Italian Space Agency (ASI)
	    5.	Japan Aerospace Exploration Agency (JAXA)
	    6.	Chinese National Space Administration (CNSA)
	    7.	Indian Space Research Organisation (ISRO)
	    8.	Israel Space Agency (ISA)
	    9.	Iranian Space Agency (ISA)
	    10.	
	  B.	Document Licensing Consideration
	II.	Recruitment
	  A.	Materials - The How
	    1.	Social Media
	    2.	Invitations
	    3.	Miscellaneous
	  B.	Participants
	  C.	Contributors
	IV.	TOMPL Completion
	V.	Governance Review Planning
	VI.	Elections
	VII.	The First Complete Plan by July 1, 2015 (TOMP vXXXX.Q)
	VIII.	Quarter-Annual Stable Updates, thereafter.
	IX. ETC.
	
	
	
THIS PROJECT IS MEANT TO HELP EVERYONE GET TO THE FINAL FRONTIER. LET'S AT IT!
>>>>>>> cf9c5f101deec87ef8d2be360e6aada280ce5a6d
